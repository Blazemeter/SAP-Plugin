package com.blazemeter.jmeter.correlation.sap;

import com.blazemeter.jmeter.correlation.core.CorrelationEngine;
import com.blazemeter.jmeter.correlation.core.CorrelationRule;
import com.blazemeter.jmeter.correlation.core.ResultField;
import com.blazemeter.jmeter.correlation.core.extractors.RegexCorrelationExtractor;
import com.blazemeter.jmeter.correlation.core.replacements.FunctionReplacement;
import com.blazemeter.jmeter.correlation.core.replacements.RegexReplacement;
import java.util.Arrays;
import java.util.List;
import org.apache.http.entity.ContentType;
import org.apache.jmeter.protocol.http.sampler.HTTPSamplerBase;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.testelement.TestElement;

public class SapCorrelationEngine extends CorrelationEngine<SapContext> {

  public SapCorrelationEngine() {
    context = new SapContext();
    rules = Arrays.asList(
    		
    		new CorrelationRule("SAP_moinId",
    	            new RegexCorrelationExtractor("id=\"moin\" name=\"moin\" value=\"(.+?)\" /><", 1, ResultField.BODY),
    	            new RegexReplacement("moin=([^&\\n]+)"))
    		
    		,new CorrelationRule("SAP_path",
    	            new RegexCorrelationExtractor("id=\"~path\" name=\"~path\" value=\"(.+?)\" /><", 1, ResultField.BODY),
    	            new RegexReplacement("~path=([^&\\n]+)"))
    		
    		,new CorrelationRule("SAP_path",
    	            new RegexCorrelationExtractor("id=\"~path\" name=\"~path\" value=\"(.+?)\" /><", 1, ResultField.BODY),
    	            new RegexReplacement("([^&\\n]+)\\/batch")),
    		
    		new CorrelationRule("SAP_path",
    	            new RegexCorrelationExtractor("id=\"~path\" name=\"~path\" value=\"(.+?)\" /><", 1, ResultField.BODY),
    	            new RegexReplacement("vhs4h1709rds.pro.coil:44300([^&\\n]+)")),
    		
    		new CorrelationRule("SAP_path",
    	            new RegexCorrelationExtractor("id=\"~path\" name=\"~path\" value=\"(.+?)\" /><", 1, ResultField.BODY),
    	            new RegexReplacement("([^&\\n]+)\\/state")),
    		
    		
    		// Exisiting csrf token
    		
    		 new CorrelationRule("SAP_xcsrfToken", 
    				 new RegexCorrelationExtractor("x-csrf-token:\\s+(.+)==", 1,ResultField.RESPONSE_HEADERS), 
    				 new RegexReplacement("([^&\\n]+)==")),
			 
    		    		
    		// Added for BT
    		
    		new CorrelationRule("sap-login-XSRF",
    	            new RegexCorrelationExtractor("\"sap-login-XSRF\" value=\"(.*?)&", 1, ResultField.BODY),
    	            new RegexReplacement("sap-login-XSRF=([^&\\n]+)=")),
    		
    		new CorrelationRule("sap-wd-secure-id",
    	            new RegexCorrelationExtractor("\"sap-wd-secure-id\" value=\"(.*?)\">", 1, ResultField.BODY),
    	            new RegexReplacement("sap-wd-secure-id=([^&\\n]+)")),
    		
    		new CorrelationRule("sap-nwbc-context",
    	            new RegexCorrelationExtractor("'sap-nwbc-context' value='(.*?)' />", 1, ResultField.BODY),
    	            new RegexReplacement("sap-nwbc-context=([^&\\n]+)")),
    		
    		new CorrelationRule("USMD_SHM_INSTANCE",
    	            new RegexCorrelationExtractor("'USMD_SHM_INSTANCE' value='(.*?)' />", 1, ResultField.BODY),
    	            new RegexReplacement("USMD_SHM_INSTANCE=([^&\\n]+)")),
    		
    		
    		
    		// Response Regex ==> RegexCorrelationExtractor
    		// Request Regex ==> RegexReplacement
    		// Match Number ==> 1/2.
    		// Field to Check ==> Body/Headers
    		
    		//Added for BT 16-oct-20
    		
    		// Table - 1
    		new CorrelationRule("client-request-id",
    	            new RegexCorrelationExtractor("client-request-id=(.*?)\"", 2, ResultField.BODY),
    	            new RegexReplacement("client-request-id=([^&\\n]+)")),
    		
    		new CorrelationRule("ctx",
    	            new RegexCorrelationExtractor("request=(.*?)&", 1, ResultField.BODY),
    	            new RegexReplacement("ctx=([^&\\n]+)")),
    		
    		new CorrelationRule("flowtoken",
    	    		new RegexCorrelationExtractor("flowToken=(.*?)\">", 1, ResultField.BODY),
    	            new RegexReplacement("flowtoken=([^&\\n]+)")),
    		
    		new CorrelationRule("SAMLResponse",
    	            new RegexCorrelationExtractor("\"SAMLResponse\" value=\"(.*?)\" />", 1, ResultField.BODY),
    	            new RegexReplacement("SAMLResponse=([^&\\n]+)")),
    		
    		new CorrelationRule("SAMLRequest",
    	            new RegexCorrelationExtractor("SAMLRequest=(.*?)&", 1, ResultField.RESPONSE_HEADERS),
    	            new RegexReplacement("SAMLRequest=([^&\\n]+)")),

    		// Table - 2
			
    		/*
			new CorrelationRule("x-csrf-token", 
					new RegexCorrelationExtractor("x-csrf-token: (.*?)==", 1,ResultField.RESPONSE_HEADERS), 
					new RegexReplacement("x-csrf-token: ([^&\\n]+)")),
			 */
    		
    		new CorrelationRule("sap-cache-id",
    	            new RegexCorrelationExtractor("cacheId&#x22;&#x3a;&#x22;(.*?)&#x22;&#x7d;,&#x22;personalization", 1, ResultField.BODY),
    	            new RegexReplacement("sap-cache-id=([^&\\n]+)")),
    		
    		// 27-oct-2020
    		new CorrelationRule("resourceId",
    	            new RegexCorrelationExtractor("\"resourceId\":\"(.*?)\",\"resourceType\"", 1, ResultField.BODY),
    	            new RegexReplacement("\"resourceId\":\"([^&\\n]+)\"")),

    		new CorrelationRule("installationID",
    	            new RegexCorrelationExtractor("\"tenantId\":\"(.*?)\",\"bnsToken\"", 1, ResultField.BODY),
    	            new RegexReplacement("\"installationID\":\"([^&\\n]+)\"")),

    		// 28-Oct-2020
    		
    		new CorrelationRule("x-csrf-token-SAC",
    	            new RegexCorrelationExtractor("x-csrf-token: (.*?)==", 1, ResultField.RESPONSE_HEADERS),
    	            new RegexReplacement("x-csrf-token: ([^&\\n]+)"))
    		
    		
    		);
  }

  private static CorrelationRule buildRule(String paramName) {
    return new CorrelationRule("Sap_" + paramName, paramName + "=(.*?)&",
        buildReplacementRegex(paramName));
  }

  private static String buildReplacementRegex(String paramNameRegex) {
    return paramNameRegex + "=([^&\\n]+)";
  }

  @Override
  public void process(HTTPSamplerBase sampler, List<TestElement> children, SampleResult result) {
    context.update(result.getResponseDataAsString());
    rules.forEach(r -> r.applyReplacements(sampler, children, result, vars));
    /*if (!ContentType.TEXT_HTML.getMimeType().equals(result.getMediaType())) {
      return;
    }*/
    rules.forEach(r -> r.addExtractors(sampler, children, result, vars));
  }

}
