package com.blazemeter.jmeter.correlation.sap;

import com.blazemeter.jmeter.correlation.core.CorrelationEngine;
import com.blazemeter.jmeter.correlation.core.CorrelationRule;
import com.blazemeter.jmeter.correlation.core.ResultField;
import com.blazemeter.jmeter.correlation.core.extractors.RegexCorrelationExtractor;
import com.blazemeter.jmeter.correlation.core.replacements.FunctionReplacement;
import com.blazemeter.jmeter.correlation.core.replacements.RegexReplacement;
import java.util.Arrays;
import java.util.List;
import org.apache.http.entity.ContentType;
import org.apache.jmeter.protocol.http.sampler.HTTPSamplerBase;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.testelement.TestElement;

public class SapCorrelationEngine extends CorrelationEngine<SapContext> {

  public SapCorrelationEngine() {
    context = new SapContext();
    rules = Arrays.asList(
    		
    		new CorrelationRule("SAP_moinId",
    	            new RegexCorrelationExtractor("id=\"moin\" name=\"moin\" value=\"(.+?)\" /><", 1, ResultField.BODY),
    	            new RegexReplacement("moin=([^&\\n]+)"))
    		
    		,new CorrelationRule("SAP_path",
    	            new RegexCorrelationExtractor("id=\"~path\" name=\"~path\" value=\"(.+?)\" /><", 1, ResultField.BODY),
    	            new RegexReplacement("~path=([^&\\n]+)"))
    		
    		,new CorrelationRule("SAP_path",
    	            new RegexCorrelationExtractor("id=\"~path\" name=\"~path\" value=\"(.+?)\" /><", 1, ResultField.BODY),
    	            new RegexReplacement("([^&\\n]+)\\/batch")),
    		
    		new CorrelationRule("SAP_path",
    	            new RegexCorrelationExtractor("id=\"~path\" name=\"~path\" value=\"(.+?)\" /><", 1, ResultField.BODY),
    	            new RegexReplacement("vhs4h1709rds.pro.coil:44300([^&\\n]+)")),
    		
    		new CorrelationRule("SAP_path",
    	            new RegexCorrelationExtractor("id=\"~path\" name=\"~path\" value=\"(.+?)\" /><", 1, ResultField.BODY),
    	            new RegexReplacement("([^&\\n]+)\\/state")),
    		
    		new CorrelationRule("SAP_xcsrfToken",
    	            new RegexCorrelationExtractor("x-csrf-token:\\s+(.+)==", 1, ResultField.RESPONSE_HEADERS),
    	            new RegexReplacement("([^&\\n]+)=="))
    		
    		);
  }

  private static CorrelationRule buildRule(String paramName) {
    return new CorrelationRule("Sap_" + paramName, paramName + "=(.*?)&",
        buildReplacementRegex(paramName));
  }

  private static String buildReplacementRegex(String paramNameRegex) {
    return paramNameRegex + "=([^&\\n]+)";
  }

  @Override
  public void process(HTTPSamplerBase sampler, List<TestElement> children, SampleResult result) {
    context.update(result.getResponseDataAsString());
    rules.forEach(r -> r.applyReplacements(sampler, children, result, vars));
    /*if (!ContentType.TEXT_HTML.getMimeType().equals(result.getMediaType())) {
      return;
    }*/
    rules.forEach(r -> r.addExtractors(sampler, children, result, vars));
  }

}
