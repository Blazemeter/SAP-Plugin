package com.blazemeter.jmeter.correlation.core;

public interface CorrelationContext {

  void reset();

}
