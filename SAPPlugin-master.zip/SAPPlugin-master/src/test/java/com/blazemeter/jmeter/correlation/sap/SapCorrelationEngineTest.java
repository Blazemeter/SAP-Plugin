package com.blazemeter.jmeter.correlation.sap;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.extractor.JSR223PostProcessor;
import org.apache.jmeter.extractor.RegexExtractor;
import org.apache.jmeter.extractor.gui.RegexExtractorGui;
import org.apache.jmeter.modifiers.JSR223PreProcessor;
import org.apache.jmeter.protocol.http.control.HeaderManager;
import org.apache.jmeter.protocol.http.sampler.HTTPSampler;
import org.apache.jmeter.protocol.http.sampler.HTTPSamplerBase;
import org.apache.jmeter.protocol.http.util.HTTPArgument;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.testbeans.gui.TestBeanGUI;
import org.apache.jmeter.testelement.TestElement;
import org.assertj.core.api.JUnitSoftAssertions;
import org.junit.Rule;
import org.junit.Test;

import com.blazemeter.jmeter.correlation.TestUtils;

public class SapCorrelationEngineTest {

	 private HTTPSamplerBase httpSampler;

	  private List<TestElement> childrenExtractor;
	  private List<TestElement> childrenReplacement;
	  private HTTPSamplerBase httpSamplerExtractor;
	  private HTTPSamplerBase httpSamplerReplacement;
	  private SampleResult sampleResultExtractor;
	  private SampleResult sampleResultReplacement;
	  
	  
	  
	  @Rule
	  public final JUnitSoftAssertions softly = new JUnitSoftAssertions();

	  @Test
	  public void shouldGenerateAllExtractors()
	      throws MalformedURLException {
		SapCorrelationEngine sapCorrelationEngine = new SapCorrelationEngine();
	    httpSamplerExtractor = createHTTPSampler(new Arguments());
	    childrenExtractor = new ArrayList<>();
	    childrenExtractor.add(new HeaderManager());
	    List<TestElement> childrenExpected = createChildrenExpectedExtractorsAndReplacementsExceptArrays();
	    sampleResultExtractor = createSampleResultExtractorExceptArrays();
	    sapCorrelationEngine.process(httpSamplerExtractor, childrenExtractor, sampleResultExtractor);
	    
	    httpSamplerReplacement = createHTTPSampler(createArgumentsReplacementExceptsArray());
	    childrenReplacement = new ArrayList<>();
	    childrenReplacement.add(new HeaderManager());
	    sampleResultReplacement = createSampleResultReplacementExceptArrays();
	    sapCorrelationEngine
	        .process(httpSamplerReplacement, childrenReplacement, sampleResultReplacement);
	    softly.assertThat(httpSamplerReplacement.getArguments())
        .isEqualTo(createExpectedArgumentsReplacementExceptsArray());
	    
	    softly.assertThat(TestUtils.comparableFrom(childrenExtractor))
	        .isEqualTo(TestUtils.comparableFrom(childrenExpected));
	  }

	  private Arguments createArgumentsReplacementExceptsArray() {
	    Arguments arguments = new Arguments();
	    arguments.addArgument(new HTTPArgument("moin", "091607C74638BDB1", "=", false));
	    arguments.addArgument(new HTTPArgument("~path", "/sap(cz1TSUQlM2FBTk9OJTNhdmhzNGgxNzA5cmRzX1M0SF8wMCUzYThmaTlIRWZFZ0g0ZllqYXo1Zlp6U2dDcmUxYWg2aGFWXzdmbFJjdWktQVRU)/bc/gui/sap/its/webgui", "=", false));
	    arguments.addArgument(new HTTPArgument("x-csrf-token","89Xpdjd7d-Ed3kow7lyY9Q==","=",false));
	    return arguments;
	  }

	  private Arguments createExpectedArgumentsReplacementExceptsArray() {
	    Arguments expectedArguments = new Arguments();
	    expectedArguments.addArgument(new HTTPArgument("moin", "${SAP_moinId}", "=", false));
	    expectedArguments.addArgument(new HTTPArgument("~path", "${SAP_path}", "=", false));
	   expectedArguments.addArgument(new HTTPArgument("x-csrf-token", "${SAP_xcsrfToken}==", "=", false));
	    return expectedArguments;
	  }

	  private SampleResult createSampleResultExtractorExceptArrays() throws MalformedURLException {
	    SampleResult sampleResultExtractor = new SampleResult();
	    sampleResultExtractor.setSamplerData("id=\"moin\" name=\"moin\" value=\"091607C74638BDB1\" /><");
	    sampleResultExtractor.setURL(new URL("https://punsezsapvm20.ad.infosys.com:44300/sap/bc/ui5_ui5/ui2/ushell/shells/abap/FioriLaunchpad.html"));
	    sampleResultExtractor.setResponseHeaders("x-csrf-token: 89Xpdjd7d-Ed3kow7lyY9Q==");
	    sampleResultExtractor.setRequestHeaders("");
	    sampleResultExtractor.setResponseCodeOK();
	    sampleResultExtractor.setResponseMessageOK();
	    sampleResultExtractor.setContentType("text/html");
	    sampleResultExtractor.setResponseData("id=\"moin\" name=\"moin\" value=\"091607C74638BDB1\" /><\n"
	            + "id=\"~path\" name=\"~path\" value=\"/sap(cz1TSUQlM2FBTk9OJTNhdmhzNGgxNzA5cmRzX1M0SF8wMCUzYThmaTlIRWZFZ0g0ZllqYXo1Zlp6U2dDcmUxYWg2aGFWXzdmbFJjdWktQVRU)/bc/gui/sap/its/webgui\" /><\n"
	        , SampleResult.DEFAULT_HTTP_ENCODING);
	    return sampleResultExtractor;
	  }

	  private SampleResult createSampleResultReplacementExceptArrays() throws MalformedURLException {
	    SampleResult sampleResultReplacement = new SampleResult();
	    sampleResultReplacement.setSamplerData("moin=091607C74638BDB1");
	    sampleResultReplacement.setURL(new URL("https://punsezsapvm20.ad.infosys.com:44300/sap/bc/ui5_ui5/ui2/ushell/shells/abap/FioriLaunchpad.html"));
	    sampleResultReplacement.setResponseHeaders("");
	    sampleResultReplacement.setRequestHeaders("");
	    sampleResultReplacement.setResponseCodeOK();
	    sampleResultReplacement.setResponseMessageOK();
	    sampleResultReplacement.setResponseData("", SampleResult.DEFAULT_HTTP_ENCODING);
	    return sampleResultReplacement;
	  }

	  private List<TestElement> createChildrenExpectedExtractorsAndReplacementsExceptArrays() {
	    List<TestElement> childrenExpected = new ArrayList<>();
	    childrenExpected.add(new HeaderManager());
	    
	    childrenExpected
	        .add(createRegexExtractor("SAP_moinId","id=\"moin\" name=\"moin\" value=\"(.+?)\" /><", "1", "1",
	            RegexExtractor.USE_BODY));
	    childrenExpected
        .add(createRegexExtractor("SAP_path","id=\"~path\" name=\"~path\" value=\"(.+?)\" /><", "1", "1",
            RegexExtractor.USE_BODY));
	    childrenExpected
        .add(createRegexExtractor("SAP_path","id=\"~path\" name=\"~path\" value=\"(.+?)\" /><", "1", "1",
            RegexExtractor.USE_BODY));
	    childrenExpected
        .add(createRegexExtractor("SAP_path","id=\"~path\" name=\"~path\" value=\"(.+?)\" /><", "1", "1",
            RegexExtractor.USE_BODY));
	    childrenExpected
        .add(createRegexExtractor("SAP_path","id=\"~path\" name=\"~path\" value=\"(.+?)\" /><", "1", "1",
            RegexExtractor.USE_BODY));
	    childrenExpected
	        .add(createRegexExtractor("SAP_xcsrfToken","x-csrf-token:\\s+(.+)==", "1", "1",
	            RegexExtractor.USE_HDRS));
	    
	    return childrenExpected;
	  }

	  private HTTPSamplerBase createHTTPSampler(Arguments arguments) {
	    httpSampler = new HTTPSampler();
	    httpSampler.setArguments(arguments);
	    httpSampler.setDomain("punsezsapvm20.ad.infosys.com");
	    httpSampler.setPort(44300);
	    httpSampler.setProtocol("https");
	    httpSampler.setContentEncoding("UTF-8");
	    httpSampler.setPath("/sap/bc/ui5_ui5/ui2/ushell/shells/abap/FioriLaunchpad.html");
	    httpSampler.setMethod("POST");
	    return httpSampler;
	  }
	  
	  private RegexExtractor createRegexExtractor(String name, String regex, String group,
	      String matchNumber,
	      String target) {
	    RegexExtractor regexExtractor = new RegexExtractor();
	    regexExtractor.setProperty(TestElement.GUI_CLASS, RegexExtractorGui.class.getName());
	    regexExtractor.setName("RegExp - " + name);
	    regexExtractor.setRefName(name);
	    regexExtractor.setRegex(regex);
	    regexExtractor.setTemplate("$" + group + "$");
	    regexExtractor.setMatchNumber(matchNumber);
	    regexExtractor.setDefaultValue("NOT_FOUND");
	    regexExtractor.setUseField(target);
	    return regexExtractor;
	  }
}
